package de.loopboost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

val BG = Color(0xFF0A0F2C)
val CARD = Color(0xFF111A3A)
val BORDER = Color(0xFF22305A)
val CYAN = Color(0xFF22D3EE)
val ORANGE = Color(0xFFF59E0B)
val RED = Color(0xFFEF4444)
val GREEN = Color(0xFF22C55E)
val DIM = Color(0xFF9AA5C4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Dashboard() } }
    }
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD)
            .border(1.dp, BORDER, RoundedCornerShape(18.dp)).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
fun Big(value: String, unit: String, color: Color) {
    Row(verticalAlignment = Alignment.Bottom) {
        Text(value, color = color, fontSize = 52.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(6.dp))
        Text(unit, color = color, fontSize = 22.sp, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
fun Lines(vararg l: String) {
    l.forEach { Text(it, color = Color(0xFFD7DDF0), fontSize = 14.sp, textAlign = TextAlign.Center) }
}

@Composable
fun Graph(v: List<Int>, lo: Float, hi: Float, c: Color) {
    Canvas(Modifier.fillMaxWidth().height(80.dp)) {
        if (v.size < 2) return@Canvas
        val path = Path()
        v.forEachIndexed { i, x ->
            val px = size.width * i / (v.size - 1)
            val py = size.height * (1 - ((x - lo) / (hi - lo)).coerceIn(0f, 1f))
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        drawPath(path, c, style = Stroke(width = 3f))
    }
}

@Composable
fun ToggleRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = GREEN, checkedThumbColor = Color.White))
    }
}

@Composable
fun Bar(frac: Float, color: Color) {
    Box(Modifier.width(110.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF1E2A50))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(frac.coerceIn(0f, 1f)).background(color))
    }
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("lb", 0) }
    fun save(k: String, v: Boolean) { prefs.edit().putBoolean(k, v).apply() }

    var permTick by remember { mutableIntStateOf(0) }
    var scanTick by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permTick++ }
    LaunchedEffect(Unit) {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) p += listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else p += Manifest.permission.READ_EXTERNAL_STORAGE
        permLauncher.launch(p.toTypedArray())
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) permTick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }

    var dnsOn by remember { mutableStateOf(prefs.getBoolean("dns", true)) }
    var adOn by remember { mutableStateOf(prefs.getBoolean("adblock", true)) }
    var pingOn by remember { mutableStateOf(prefs.getBoolean("ping", true)) }
    var wifiOn by remember { mutableStateOf(prefs.getBoolean("wifi", true)) }
    var hogsOn by remember { mutableStateOf(prefs.getBoolean("hogs", true)) }
    var prov by remember { mutableIntStateOf(prefs.getInt("prov", 0)) }

    // ---- VPN (DNS + Werbeblocker)
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) ctx.startService(Intent(ctx, DnsVpnService::class.java))
        else { dnsOn = false; adOn = false; save("dns", false); save("adblock", false) }
    }
    LaunchedEffect(dnsOn, adOn, prov, permTick > 0) {
        if (permTick == 0) return@LaunchedEffect
        if (dnsOn || adOn) {
            val i = VpnService.prepare(ctx)
            if (i != null) vpnLauncher.launch(i) else ctx.startService(Intent(ctx, DnsVpnService::class.java))
        } else if (DnsVpnService.running) {
            ctx.startService(Intent(ctx, DnsVpnService::class.java).setAction("STOP"))
        }
    }
    var fwd by remember { mutableIntStateOf(0) }
    var blk by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { fwd = DnsVpnService.forwarded.get(); blk = DnsVpnService.blocked.get(); delay(1000) } }

    // ---- Ping
    val pings = remember { mutableStateListOf<Int>() }
    var sent by remember { mutableIntStateOf(0) }
    var lost by remember { mutableIntStateOf(0) }
    LaunchedEffect(pingOn) {
        while (pingOn) {
            val r = withContext(Dispatchers.IO) { tcpPing() }
            sent++
            if (r == null) lost++ else { pings.add(r); if (pings.size > 60) pings.removeAt(0) }
            delay(1000)
        }
    }

    // ---- WLAN
    val wifiHist = remember { mutableStateListOf<Int>() }
    var wifi by remember { mutableStateOf<WifiData?>(null) }
    var wifiGaps by remember { mutableIntStateOf(0) }
    LaunchedEffect(wifiOn, permTick) {
        while (wifiOn) {
            val w = readWifi(ctx); wifi = w
            if (w == null) wifiGaps++ else { wifiHist.add(w.rssi); if (wifiHist.size > 60) wifiHist.removeAt(0) }
            delay(2000)
        }
    }

    // ---- Mobilfunk
    val cellHist = remember { mutableStateListOf<Int>() }
    var cell by remember { mutableStateOf<CellData?>(null) }
    var cellGaps by remember { mutableIntStateOf(0) }
    LaunchedEffect(permTick) {
        while (true) {
            val cd = readCell(ctx); cell = cd
            if (cd == null) cellGaps++ else { cellHist.add(cd.dbm); if (cellHist.size > 60) cellHist.removeAt(0) }
            delay(2000)
        }
    }

    // ---- System
    var sys by remember { mutableStateOf(readSys(ctx)) }
    LaunchedEffect(Unit) { while (true) { sys = readSys(ctx); delay(3000) } }

    // ---- Speicher
    var files by remember { mutableStateOf(listOf<BigFile>()) }
    var cache by remember { mutableLongStateOf(0L) }
    LaunchedEffect(permTick, scanTick) {
        withContext(Dispatchers.IO) { files = scanFiles(ctx); cache = cacheBytes(ctx) }
    }
    val delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { scanTick++ }
    fun askDelete(f: BigFile) {
        if (Build.VERSION.SDK_INT >= 30) {
            val pi = MediaStore.createDeleteRequest(ctx.contentResolver, listOf(f.uri))
            delLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else Toast.makeText(ctx, "Löschen geht erst ab Android 11", Toast.LENGTH_LONG).show()
    }

    // ---- Daten-Fresser
    var usage by remember { mutableStateOf(false) }
    var hogs by remember { mutableStateOf(listOf<Pair<String, Long>>()) }
    LaunchedEffect(hogsOn, permTick) {
        usage = hasUsage(ctx)
        if (hogsOn && usage) hogs = withContext(Dispatchers.IO) { topApps(ctx) }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(340.dp),
        modifier = Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // PING
        item {
            Panel("INTERNET-QUALITÄT (PING)") {
                if (!pingOn) Text("Ping-Monitor ist aus", color = DIM)
                else if (pings.isEmpty()) Text(if (sent > 0) "Keine Verbindung" else "Messe …", color = RED, fontSize = 20.sp)
                else {
                    val last = pings.last()
                    val (lbl, col) = when { last < 50 -> "Sehr gut" to GREEN; last < 100 -> "Gut" to CYAN; last < 200 -> "Okay" to ORANGE; else -> "Schlecht" to RED }
                    Big("$last", "ms", CYAN)
                    Text(lbl, color = col, fontSize = 20.sp)
                    Graph(pings, 0f, maxOf(100, pings.max()).toFloat(), CYAN)
                    val jit = if (pings.size > 1) pings.zipWithNext { a, b -> kotlin.math.abs(a - b) }.average() else 0.0
                    Lines(
                        "Durchschnitt: ${pings.average().toInt()} ms",
                        "Min / Max: ${pings.min()} / ${pings.max()} ms",
                        String.format(Locale.GERMANY, "Jitter: %.1f ms", jit),
                        "Paketverlust: ${if (sent > 0) lost * 100 / sent else 0} %"
                    )
                }
            }
        }
        // WLAN
        item {
            Panel("WLAN-MONITOR") {
                val w = wifi
                if (!wifiOn) Text("WLAN-Check ist aus", color = DIM)
                else if (w == null) Text("Nicht mit WLAN verbunden", color = DIM)
                else {
                    val (lbl, col) = when { w.rssi >= -50 -> "Ausgezeichnet" to GREEN; w.rssi >= -60 -> "Gut" to CYAN; w.rssi >= -70 -> "Okay" to ORANGE; else -> "Schwach" to RED }
                    Big("${w.rssi}", "dBm", col)
                    Text(lbl, color = col, fontSize = 20.sp)
                    Graph(wifiHist, -90f, -30f, col)
                    Lines(
                        "Durchschnitt: ${wifiHist.average().toInt()} dBm",
                        "Min / Max: ${wifiHist.min()} / ${wifiHist.max()} dBm",
                        "Aussetzer: $wifiGaps",
                        "Netz: ${w.ssid}",
                        "Frequenz: ${if (w.freq >= 5000) "5 GHz" else "2,4 GHz"} (${w.freq} MHz)",
                        "Verbindungsrate: ${w.link} Mbit/s"
                    )
                }
            }
        }
        // MOBIL
        item {
            Panel("MOBILFUNK-MONITOR") {
                val cd = cell
                if (cd == null) Text("Kein Mobilfunk-Signal (oder keine SIM / Berechtigung)", color = DIM, textAlign = TextAlign.Center)
                else {
                    val (lbl, col) = when { cd.dbm >= -85 -> "Gut" to GREEN; cd.dbm >= -100 -> "Okay" to ORANGE; else -> "Schwach" to RED }
                    Big("${cd.dbm}", "dBm", col)
                    Text("$lbl (${cd.type})", color = col, fontSize = 20.sp)
                    Graph(cellHist, -130f, -50f, col)
                    Lines(
                        "Netztyp: ${cd.type}",
                        "Aussetzer: $cellGaps",
                        "Netz: ${cd.op}",
                        "Frequenz: ${cd.band}",
                        "Verbindungsrate: ${cd.mbit} Mbit/s"
                    )
                }
            }
        }
        // BOOSTER
        item {
            Panel("INTERNET-BOOSTER") {
                ToggleRow("Schnelles DNS", dnsOn) { dnsOn = it; save("dns", it) }
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).border(1.dp, BORDER, RoundedCornerShape(8.dp))
                        .clickable { prov = (prov + 1) % PROVIDERS.size; prefs.edit().putInt("prov", prov).apply() }
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) { Text("DNS-ANBIETER: ${PROVIDERS[prov].first.uppercase()} (TIPPEN ZUM WECHSELN)", color = Color.White, fontSize = 12.sp) }
                ToggleRow("Werbe- und Tracker-Blocker", adOn) { adOn = it; save("adblock", it) }
                ToggleRow("Ping-Monitor (Ping, Jitter, Paketverlust)", pingOn) { pingOn = it; save("ping", it) }
                ToggleRow("WLAN-Check (Band, Signal, Tipps)", wifiOn) { wifiOn = it; save("wifi", it) }
                ToggleRow("Daten-Fresser anzeigen", hogsOn) { hogsOn = it; save("hogs", it) }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (dnsOn || adOn) "DNS aktiv: ${if (dnsOn) PROVIDERS[prov].first else "System"}" else "DNS/Blocker aus",
                    color = DIM, fontSize = 13.sp
                )
                Text("Anfragen: $fwd weitergeleitet, $blk blockiert", color = DIM, fontSize = 13.sp)
            }
        }
        // SPEICHER
        item {
            Panel("SPEICHER AUFRÄUMEN") {
                val dupSum = files.filter { it.dup }.sumOf { it.size }
                val bigSum = files.filter { !it.dup }.sumOf { it.size }
                Big(String.format(Locale.GERMANY, "%.1f", (cache + dupSum + bigSum) / 1e9), "GB", CYAN)
                Text("Freigebbarer Datenmüll", color = GREEN, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("• Cache-Dateien", color = Color.White); Text(sizeText(cache), color = Color.White) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("• Große Dateien (>50 MB)", color = Color.White); Text(sizeText(bigSum), color = Color.White) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("• Doppelte Dateien", color = Color.White); Text(sizeText(dupSum), color = Color.White) }
                Spacer(Modifier.height(8.dp))
                files.take(6).forEach { f ->
                    Row(Modifier.fillMaxWidth().clickable { askDelete(f) }.padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text((if (f.dup) "[doppelt] " else "") + f.name, color = DIM, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        Text("${sizeText(f.size)}  Löschen", color = ORANGE, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    clearCache(ctx); cache = 0
                    Toast.makeText(ctx, "Cache gelöscht. Dateien oben einzeln antippen zum Löschen.", Toast.LENGTH_LONG).show()
                }, colors = ButtonDefaults.buttonColors(containerColor = GREEN)) { Text("Speicher jetzt freigeben", color = Color.Black) }
            }
        }
        // SYSTEM
        item {
            Panel("SYSTEM- & GERÄTE-MONITOR") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, BORDER, RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text("Geräte-Monitor", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("RAM: ${gb(sys.ramUsed)} / ${gb(sys.ramTotal)}", color = Color.White, fontSize = 13.sp)
                        Bar(sys.ramUsed.toFloat() / sys.ramTotal, Color(0xFF3B82F6))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Speicher: ${gb(sys.stUsed)} / ${gb(sys.stTotal)}", color = Color.White, fontSize = 13.sp)
                        Bar(sys.stUsed.toFloat() / sys.stTotal, GREEN)
                    }
                    Text("CPU: nicht lesbar (Android-Sperre) • Akku-Temp: ${String.format(Locale.GERMANY, "%.0f", sys.temp)}°C", color = DIM, fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, BORDER, RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text("Akku-Info", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("${sys.batt}% (${if (sys.charging) "Lädt" else "Entlädt"}) • ${String.format(Locale.GERMANY, "%.0f", sys.temp)}°C", color = Color.White)
                    if (hogsOn) {
                        Spacer(Modifier.height(6.dp))
                        Text("Verbrauch pro App (24 h)", color = CYAN, fontWeight = FontWeight.Bold)
                        if (!usage) {
                            Text("Tippen und \"LoopBoost\" erlauben →", color = ORANGE, modifier = Modifier.clickable {
                                ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                            }.padding(vertical = 4.dp))
                        } else if (hogs.isEmpty()) Text("Noch keine Daten", color = DIM)
                        else hogs.forEach {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(it.first, color = Color.White, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
                                Text(sizeText(it.second), color = Color.White, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
