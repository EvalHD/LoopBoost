package de.loopboost

import android.Manifest
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.provider.MediaStore
import android.telephony.CellInfoLte
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale

fun tcpPing(): Int? = try {
    Socket().use { s ->
        val t = System.nanoTime()
        s.connect(InetSocketAddress("1.1.1.1", 443), 2000)
        ((System.nanoTime() - t) / 1_000_000).toInt()
    }
} catch (e: Exception) { null }

data class WifiData(val rssi: Int, val freq: Int, val link: Int, val ssid: String)

@Suppress("DEPRECATION")
fun readWifi(c: Context): WifiData? {
    val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    if (!wm.isWifiEnabled) return null
    val i = wm.connectionInfo ?: return null
    if (i.rssi < -126 || i.frequency <= 0) return null
    return WifiData(i.rssi, i.frequency, i.linkSpeed, i.ssid?.trim('"') ?: "")
}

data class CellData(val dbm: Int, val type: String, val op: String, val band: String, val mbit: Int)

fun readCell(c: Context): CellData? = try {
    val tm = c.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    val cs = tm.signalStrength?.cellSignalStrengths?.firstOrNull()
    if (cs == null || cs.dbm !in -140..-30) null else {
        val n = cs.javaClass.simpleName
        val type = when {
            "Nr" in n -> "5G"; "Lte" in n -> "LTE"; "Wcdma" in n -> "3G"; "Gsm" in n -> "2G"; else -> "?"
        }
        var band = "–"
        try {
            if (Build.VERSION.SDK_INT >= 30 &&
                ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                val ci = tm.allCellInfo.firstOrNull { it.isRegistered && it is CellInfoLte } as? CellInfoLte
                val b = ci?.cellIdentity?.bands?.firstOrNull()
                if (b != null) band = "Band $b"
            }
        } catch (e: Exception) { }
        var mb = 0
        val cm = c.getSystemService(ConnectivityManager::class.java)
        cm.allNetworks.forEach {
            val nc = cm.getNetworkCapabilities(it)
            if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) mb = nc.linkDownstreamBandwidthKbps / 1000
        }
        CellData(cs.dbm, type, tm.networkOperatorName ?: "", band, mb)
    }
} catch (e: Exception) { null }

data class SysData(val ramUsed: Long, val ramTotal: Long, val stUsed: Long, val stTotal: Long,
                   val batt: Int, val charging: Boolean, val temp: Float)

fun readSys(c: Context): SysData {
    val am = c.getSystemService(ActivityManager::class.java)
    val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
    val sf = StatFs(Environment.getDataDirectory().path)
    val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0
    val t = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    return SysData(mi.totalMem - mi.availMem, mi.totalMem, sf.totalBytes - sf.availableBytes, sf.totalBytes,
        lvl * 100 / sc, st == 2 || st == 5, t)
}

data class BigFile(val uri: Uri, val name: String, val size: Long, val dup: Boolean)

fun scanFiles(c: Context): List<BigFile> = try {
    val base = MediaStore.Files.getContentUri("external")
    val proj = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE)
    val seen = HashSet<String>()
    val out = ArrayList<BigFile>()
    c.contentResolver.query(base, proj, "${MediaStore.Files.FileColumns.SIZE} > ?", arrayOf("1048576"),
        "${MediaStore.Files.FileColumns.SIZE} DESC")?.use { cur ->
        var rows = 0
        while (cur.moveToNext() && rows < 400) {
            rows++
            val id = cur.getLong(0); val name = cur.getString(1) ?: "?"; val size = cur.getLong(2)
            val key = "$name|$size"
            val dup = !seen.add(key)
            if (dup || size >= 50L * 1024 * 1024) out.add(BigFile(ContentUris.withAppendedId(base, id), name, size, dup))
        }
    }
    out.take(40)
} catch (e: Exception) { emptyList() }

fun cacheBytes(c: Context): Long = c.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
fun clearCache(c: Context) { c.cacheDir.listFiles()?.forEach { it.deleteRecursively() } }

@Suppress("DEPRECATION")
fun hasUsage(c: Context): Boolean {
    val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val m = if (Build.VERSION.SDK_INT >= 29)
        ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    else ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    return m == AppOpsManager.MODE_ALLOWED
}

fun topApps(c: Context): List<Pair<String, Long>> = try {
    val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
    val end = System.currentTimeMillis(); val start = end - 24L * 3600 * 1000
    val map = HashMap<Int, Long>()
    for (type in listOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
        val st = try { nsm.querySummary(type, null, start, end) } catch (e: Exception) { continue }
        val b = NetworkStats.Bucket()
        while (st.hasNextBucket()) { st.getNextBucket(b); map[b.uid] = (map[b.uid] ?: 0L) + b.rxBytes + b.txBytes }
        st.close()
    }
    val pm = c.packageManager
    map.entries.sortedByDescending { it.value }.take(30).mapNotNull { e ->
        val pkg = pm.getPackagesForUid(e.key)?.firstOrNull() ?: return@mapNotNull null
        val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (x: Exception) { pkg }
        label to e.value
    }.take(5)
} catch (e: Exception) { emptyList() }

fun gb(b: Long) = String.format(Locale.GERMANY, "%.1f GB", b / 1e9)
fun sizeText(b: Long) = if (b >= 1e9) gb(b) else String.format(Locale.GERMANY, "%.0f MB", b / 1e6)
