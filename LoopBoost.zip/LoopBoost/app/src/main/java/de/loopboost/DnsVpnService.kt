package de.loopboost

import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

val PROVIDERS = listOf("Cloudflare" to "1.1.1.1", "Google" to "8.8.8.8", "Quad9" to "9.9.9.9")

private val BLOCKED = listOf(
    "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
    "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com", "criteo.com",
    "criteo.net", "scorecardresearch.com", "moatads.com", "amazon-adsystem.com", "applovin.com",
    "adcolony.com", "chartboost.com", "inmobi.com", "vungle.com", "mopub.com", "ironsrc.com",
    "supersonicads.com", "unityads.unity3d.com", "flurry.com", "app-measurement.com", "hotjar.com",
    "mixpanel.com", "pubmatic.com", "rubiconproject.com", "openx.net", "smaato.net", "adform.net",
    "quantserve.com", "bat.bing.com", "ads.yahoo.com", "advertising.com", "adjust.io"
)

class DnsVpnService : VpnService() {

    companion object {
        @Volatile var running = false
        val forwarded = AtomicInteger()
        val blocked = AtomicInteger()
    }

    private var tun: ParcelFileDescriptor? = null
    private var pool = Executors.newCachedThreadPool()
    private var adblock = true
    private var upstream = "1.1.1.1"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopVpn(); stopSelf(); return START_NOT_STICKY }
        stopVpn()
        val p = getSharedPreferences("lb", 0)
        adblock = p.getBoolean("adblock", true)
        upstream = if (p.getBoolean("dns", true)) {
            PROVIDERS[p.getInt("prov", 0).coerceIn(0, PROVIDERS.size - 1)].second
        } else systemDns()
        startVpn()
        return START_STICKY
    }

    private fun systemDns(): String = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork)
        lp?.dnsServers?.firstOrNull { it.address.size == 4 }?.hostAddress ?: "8.8.8.8"
    } catch (e: Exception) { "8.8.8.8" }

    private fun startVpn() {
        val fd = Builder().setSession("LoopBoost")
            .addAddress("10.77.0.1", 32)
            .addDnsServer("10.77.0.2")
            .addRoute("10.77.0.2", 32)
            .setBlocking(true)
            .establish() ?: return
        tun = fd
        running = true
        pool = Executors.newCachedThreadPool()
        Thread { loop(fd) }.start()
    }

    private fun stopVpn() {
        running = false
        try { tun?.close() } catch (e: Exception) {}
        tun = null
        pool.shutdownNow()
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            val n = try { input.read(buf) } catch (e: Exception) { break }
            if (n <= 0) continue
            val pkt = buf.copyOf(n)
            try { pool.execute { handle(pkt, output) } } catch (e: Exception) { break }
        }
    }

    private fun handle(pkt: ByteArray, out: FileOutputStream) {
        try {
            if ((pkt[0].toInt() shr 4) != 4) return
            val ihl = (pkt[0].toInt() and 15) * 4
            if (pkt[9].toInt() != 17) return
            val dport = ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)
            if (dport != 53) return
            val dns = pkt.copyOfRange(ihl + 8, pkt.size)
            val parsed = parseName(dns) ?: return
            val name = parsed.first
            val resp: ByteArray
            if (adblock && BLOCKED.any { name == it || name.endsWith(".$it") }) {
                blocked.incrementAndGet()
                resp = dns.copyOf(parsed.second)
                resp[2] = 0x81.toByte(); resp[3] = 0x83.toByte()
                for (i in 6..11) resp[i] = 0
            } else {
                val s = DatagramSocket()
                protect(s)
                s.soTimeout = 3000
                s.send(DatagramPacket(dns, dns.size, InetAddress.getByName(upstream), 53))
                val rb = ByteArray(4096)
                val rp = DatagramPacket(rb, rb.size)
                s.receive(rp)
                s.close()
                resp = rb.copyOf(rp.length)
                forwarded.incrementAndGet()
            }
            val total = 28 + resp.size
            val o = ByteArray(total)
            o[0] = 0x45; o[2] = (total shr 8).toByte(); o[3] = total.toByte()
            o[8] = 64; o[9] = 17
            System.arraycopy(pkt, 16, o, 12, 4)
            System.arraycopy(pkt, 12, o, 16, 4)
            var sum = 0
            for (i in 0 until 20 step 2) sum += ((o[i].toInt() and 0xFF) shl 8) or (o[i + 1].toInt() and 0xFF)
            while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
            val ck = sum.inv() and 0xFFFF
            o[10] = (ck shr 8).toByte(); o[11] = ck.toByte()
            o[20] = pkt[ihl + 2]; o[21] = pkt[ihl + 3]
            o[22] = pkt[ihl]; o[23] = pkt[ihl + 1]
            val ul = 8 + resp.size
            o[24] = (ul shr 8).toByte(); o[25] = ul.toByte()
            System.arraycopy(resp, 0, o, 28, resp.size)
            synchronized(out) { out.write(o) }
        } catch (e: Exception) { }
    }

    private fun parseName(d: ByteArray): Pair<String, Int>? {
        if (d.size < 17) return null
        var p = 12
        val sb = StringBuilder()
        while (p < d.size) {
            val l = d[p].toInt() and 0xFF
            if (l == 0) { p++; break }
            if ((l and 0xC0) != 0) return null
            if (p + 1 + l > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, p + 1, l, Charsets.US_ASCII))
            p += l + 1
        }
        val end = p + 4
        if (end > d.size) return null
        return Pair(sb.toString().lowercase(), end)
    }
}
